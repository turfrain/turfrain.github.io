var forms_list  = ['form-calender','form-checkbox-dim','form-checkbox-off','form-checkbox-on','form-dot_tooltip-top','form-dot_tooltip','form-input-x','form-radio-dim','form-radio-off','form-radio-on','form-star-off','form-star-on','form-time','form-tooltip'];
var forms_width  = ['23','20','20','20','13','13','20','20','20','20','20','20','23','21'];
var forms_height  = ['23','20','20','20','15','15','20','20','20','20','20','20','23','21'];
