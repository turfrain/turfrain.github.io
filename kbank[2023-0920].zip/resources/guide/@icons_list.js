var icons_list  = ['icon-accordion_arrow_down','icon-accordion_arrow_up','icon-page_next','icon-page_nextnext','icon-page_prev','icon-page_prevprev','icon-pop_close','icon-pop_close@2x'];
var icons_width  = ['30','30','20','20','20','20','28','56'];
var icons_height  = ['30','30','20','20','20','20','28','56'];
